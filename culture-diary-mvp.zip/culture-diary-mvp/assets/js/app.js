const STORAGE_KEY = 'moodArchiveRecords.v1';

const seedRecords = [
  {
    id: crypto.randomUUID(),
    title: '괴물',
    category: '영화',
    consumedDate: '2026-06-03',
    place: 'CGV 용산',
    rating: 4.5,
    moodTags: ['먹먹한', '잔잔한', '오래 남는'],
    oneLineReview: '조용하지만 오래 흔들리는 이야기.',
    fullReview: '인물의 감정이 과하게 설명되지 않아서 더 오래 남았다. 보고 난 뒤에도 장면들이 천천히 떠오르는 영화였다.',
    imageUrl: '',
    visibility: 'private',
    createdAt: new Date('2026-06-03').toISOString()
  },
  {
    id: crypto.randomUUID(),
    title: '빛의 시선',
    category: '전시',
    consumedDate: '2026-06-08',
    place: '서울시립미술관',
    rating: 4,
    moodTags: ['고요한', '시각적인', '영감을 준'],
    oneLineReview: '빛과 그림자가 만들어내는 차분한 리듬.',
    fullReview: '공간의 여백이 좋아서 작품을 오래 바라보게 됐다. 전시 동선도 복잡하지 않아 집중하기 편했다.',
    imageUrl: '',
    visibility: 'private',
    createdAt: new Date('2026-06-08').toISOString()
  },
  {
    id: crypto.randomUUID(),
    title: '데미안',
    category: '책',
    consumedDate: '2026-06-11',
    place: '집',
    rating: 5,
    moodTags: ['사유적인', '깊은', '다시 읽고 싶은'],
    oneLineReview: '불안한 시기에 다시 읽고 싶은 문장들이 많았다.',
    fullReview: '예전에는 어렵게 느껴졌던 부분이 이번에는 오히려 명확하게 다가왔다. 기록으로 남겨두고 다시 읽고 싶다.',
    imageUrl: '',
    visibility: 'private',
    createdAt: new Date('2026-06-11').toISOString()
  }
];

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

let records = loadRecords();
let currentImageUrl = '';

function loadRecords() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (!saved) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(seedRecords));
    return seedRecords;
  }
  try {
    return JSON.parse(saved);
  } catch {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(seedRecords));
    return seedRecords;
  }
}

function saveRecords() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function formatDate(dateString) {
  if (!dateString) return '-';
  return new Intl.DateTimeFormat('ko-KR', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(dateString));
}

function getMonthKey(dateString) {
  const date = new Date(dateString);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
}

function uniqueValues(values) {
  return [...new Set(values.filter(Boolean))];
}

function setView(viewId) {
  $$('.view').forEach((view) => view.classList.toggle('is-visible', view.id === viewId));
  $$('.nav-item').forEach((item) => item.classList.toggle('is-active', item.dataset.view === viewId));
  const view = document.getElementById(viewId);
  $('#pageTitle').textContent = view?.dataset.title || 'Mood Archive';
  if (viewId === 'new-record' && !$('#recordId').value) resetForm();
  renderAll();
}

function getFilteredRecords() {
  const query = $('#globalSearch').value.trim().toLowerCase();
  const category = $('#categoryFilter')?.value || 'all';
  const mood = $('#moodFilter')?.value || 'all';
  const sort = $('#sortFilter')?.value || 'latest';

  let result = records.filter((record) => {
    const searchTarget = [record.title, record.category, record.place, record.oneLineReview, record.fullReview, ...(record.moodTags || [])].join(' ').toLowerCase();
    const queryOk = !query || searchTarget.includes(query);
    const categoryOk = category === 'all' || record.category === category;
    const moodOk = mood === 'all' || (record.moodTags || []).includes(mood);
    return queryOk && categoryOk && moodOk;
  });

  result.sort((a, b) => {
    if (sort === 'oldest') return new Date(a.consumedDate) - new Date(b.consumedDate);
    if (sort === 'rating') return Number(b.rating || 0) - Number(a.rating || 0);
    return new Date(b.consumedDate) - new Date(a.consumedDate);
  });
  return result;
}

function renderSummary() {
  const currentMonth = new Date().toISOString().slice(0, 7);
  const thisMonthRecords = records.filter((record) => getMonthKey(record.consumedDate) === currentMonth);
  const categoryTop = getTopItem(records.map((record) => record.category));
  const moodTop = getTopItem(records.flatMap((record) => record.moodTags || []));
  const averageRating = records.length
    ? (records.reduce((sum, record) => sum + Number(record.rating || 0), 0) / records.filter((record) => record.rating).length || 0).toFixed(1)
    : '0.0';

  const cards = [
    { label: '전체 기록', value: records.length },
    { label: '이번 달 기록', value: thisMonthRecords.length },
    { label: '대표 카테고리', value: categoryTop || '-' },
    { label: '평균 평점', value: averageRating }
  ];

  $('#summaryGrid').innerHTML = cards.map((card) => `
    <article class="summary-card">
      <strong>${card.value}</strong>
      <span>${card.label}</span>
    </article>
  `).join('');
}

function getTopItem(items) {
  const counts = items.reduce((acc, item) => {
    if (!item) return acc;
    acc[item] = (acc[item] || 0) + 1;
    return acc;
  }, {});
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0];
}

function recordCard(record) {
  const tags = (record.moodTags || []).slice(0, 3).map((tag) => `<span class="tag">${tag}</span>`).join('');
  const thumb = record.imageUrl
    ? `<img src="${record.imageUrl}" alt="${record.title} 이미지" />`
    : `<span>${record.category?.slice(0, 1) || 'M'}</span>`;

  return `
    <article class="record-card" role="button" tabindex="0" data-record-id="${record.id}">
      <div class="record-thumb">${thumb}</div>
      <div class="record-body">
        <div class="record-meta">
          <span>${record.category}</span>
          <span>${formatDate(record.consumedDate)}</span>
        </div>
        <div class="record-title">${record.title}</div>
        <p class="record-review">${record.oneLineReview || ''}</p>
        <div class="tag-list">${tags}</div>
      </div>
    </article>
  `;
}

function renderRecent() {
  const recent = [...records].sort((a, b) => new Date(b.consumedDate) - new Date(a.consumedDate)).slice(0, 3);
  $('#recentRecords').innerHTML = recent.map(recordCard).join('');
}

function renderArchive() {
  const filtered = getFilteredRecords();
  $('#archiveGrid').innerHTML = filtered.map(recordCard).join('');
  $('#archiveEmpty').hidden = filtered.length > 0;
}

function renderFilters() {
  const categories = uniqueValues(records.map((record) => record.category));
  const moods = uniqueValues(records.flatMap((record) => record.moodTags || []));
  const currentCategory = $('#categoryFilter').value;
  const currentMood = $('#moodFilter').value;

  $('#categoryFilter').innerHTML = `<option value="all">전체 카테고리</option>` + categories.map((category) => `<option value="${category}">${category}</option>`).join('');
  $('#moodFilter').innerHTML = `<option value="all">전체 감정</option>` + moods.map((mood) => `<option value="${mood}">${mood}</option>`).join('');
  $('#categoryFilter').value = categories.includes(currentCategory) ? currentCategory : 'all';
  $('#moodFilter').value = moods.includes(currentMood) ? currentMood : 'all';
}

function renderReport() {
  const categoryCounts = countItems(records.map((record) => record.category));
  const moodCounts = countItems(records.flatMap((record) => record.moodTags || []));
  const maxCategory = Math.max(1, ...Object.values(categoryCounts));

  $('#categoryChart').innerHTML = Object.entries(categoryCounts)
    .sort((a, b) => b[1] - a[1])
    .map(([category, count]) => `
      <div class="chart-item">
        <div class="chart-top"><span>${category}</span><strong>${count}개</strong></div>
        <div class="chart-bar"><div class="chart-fill" style="width:${(count / maxCategory) * 100}%"></div></div>
      </div>
    `).join('') || '<p class="record-review">기록이 쌓이면 카테고리 분석이 표시됩니다.</p>';

  $('#moodCloud').innerHTML = Object.entries(moodCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 12)
    .map(([mood, count]) => `<span class="mood-pill">${mood} · ${count}</span>`)
    .join('') || '<p class="record-review">감정 태그를 입력하면 순위가 표시됩니다.</p>';

  const topCategory = getTopItem(records.map((record) => record.category));
  const topMood = getTopItem(records.flatMap((record) => record.moodTags || []));
  $('#tasteSentence').textContent = records.length
    ? `최근 기록을 보면 ${topCategory || '문화 콘텐츠'} 경험이 가장 많고, ${topMood || '다양한'} 감정을 자주 남기고 있어요. 기록이 쌓일수록 취향의 방향이 더 선명해집니다.`
    : '아직 기록이 없습니다. 첫 문화 기록을 남기면 취향 문장이 생성됩니다.';
}

function countItems(items) {
  return items.reduce((acc, item) => {
    if (!item) return acc;
    acc[item] = (acc[item] || 0) + 1;
    return acc;
  }, {});
}

function renderAll() {
  renderFilters();
  renderSummary();
  renderRecent();
  renderArchive();
  renderReport();
  bindRecordCards();
}

function bindRecordCards() {
  $$('.record-card').forEach((card) => {
    card.onclick = () => openDetail(card.dataset.recordId);
    card.onkeydown = (event) => {
      if (event.key === 'Enter') openDetail(card.dataset.recordId);
    };
  });
}

function openDetail(id) {
  const record = records.find((item) => item.id === id);
  if (!record) return;
  const image = record.imageUrl
    ? `<img src="${record.imageUrl}" alt="${record.title} 이미지" />`
    : `<span>${record.category?.slice(0, 1) || 'M'}</span>`;
  const tags = (record.moodTags || []).map((tag) => `<span class="tag">${tag}</span>`).join('');

  $('#detailContent').innerHTML = `
    <div class="detail-layout">
      <div class="detail-image">${image}</div>
      <div class="detail-info">
        <p class="eyebrow">${record.category} · Private Record</p>
        <h3>${record.title}</h3>
        <p class="record-review">${formatDate(record.consumedDate)} · ${record.place || '장소 미입력'} · ★ ${record.rating || '-'}</p>
        <div class="tag-list">${tags}</div>
        <h4>한 줄 감상</h4>
        <p>${record.oneLineReview || '-'}</p>
        <h4>상세 감상</h4>
        <p class="full">${record.fullReview || '상세 감상이 아직 없습니다.'}</p>
        <div class="detail-actions">
          <button class="btn" data-edit-id="${record.id}">수정</button>
          <button class="btn danger" data-delete-id="${record.id}">삭제</button>
        </div>
      </div>
    </div>
  `;
  $('#detailDialog').showModal();
  $('[data-edit-id]').onclick = () => editRecord(record.id);
  $('[data-delete-id]').onclick = () => deleteRecord(record.id);
}

function resetForm() {
  $('#recordForm').reset();
  $('#recordId').value = '';
  $('#formTitle').textContent = '문화 기록 등록';
  $('#consumedDate').value = new Date().toISOString().slice(0, 10);
  currentImageUrl = '';
  $('#imagePreview').innerHTML = '이미지 미리보기';
}

function editRecord(id) {
  const record = records.find((item) => item.id === id);
  if (!record) return;
  $('#detailDialog').close();
  setView('new-record');
  $('#formTitle').textContent = '문화 기록 수정';
  $('#recordId').value = record.id;
  $('#category').value = record.category;
  $('#title').value = record.title;
  $('#consumedDate').value = record.consumedDate;
  $('#place').value = record.place || '';
  $('#rating').value = record.rating || '';
  $('#moodTags').value = (record.moodTags || []).join(', ');
  $('#oneLineReview').value = record.oneLineReview || '';
  $('#fullReview').value = record.fullReview || '';
  currentImageUrl = record.imageUrl || '';
  $('#imagePreview').innerHTML = currentImageUrl ? `<img src="${currentImageUrl}" alt="이미지 미리보기" />` : '이미지 미리보기';
}

function deleteRecord(id) {
  const ok = confirm('이 기록을 삭제할까요? 삭제 후에는 복구할 수 없습니다.');
  if (!ok) return;
  records = records.filter((record) => record.id !== id);
  saveRecords();
  $('#detailDialog').close();
  renderAll();
}

function readImage(file) {
  return new Promise((resolve) => {
    if (!file) return resolve(currentImageUrl || '');
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.readAsDataURL(file);
  });
}

async function handleSubmit(event) {
  event.preventDefault();
  const imageUrl = await readImage($('#imageFile').files[0]);
  const id = $('#recordId').value || crypto.randomUUID();
  const payload = {
    id,
    title: $('#title').value.trim(),
    category: $('#category').value,
    consumedDate: $('#consumedDate').value,
    place: $('#place').value.trim(),
    rating: Number($('#rating').value || 0),
    moodTags: $('#moodTags').value.split(',').map((tag) => tag.trim()).filter(Boolean),
    oneLineReview: $('#oneLineReview').value.trim(),
    fullReview: $('#fullReview').value.trim(),
    imageUrl,
    visibility: 'private',
    createdAt: records.find((record) => record.id === id)?.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  const index = records.findIndex((record) => record.id === id);
  if (index >= 0) records[index] = payload;
  else records.unshift(payload);

  saveRecords();
  resetForm();
  setView('archive');
}

function bindEvents() {
  $$('.nav-item').forEach((item) => item.addEventListener('click', () => setView(item.dataset.view)));
  $$('[data-view-trigger]').forEach((item) => item.addEventListener('click', () => setView(item.dataset.viewTrigger)));
  $('#globalSearch').addEventListener('input', () => {
    if (!$('#archive').classList.contains('is-visible')) setView('archive');
    renderArchive();
    bindRecordCards();
  });
  ['categoryFilter', 'moodFilter', 'sortFilter'].forEach((id) => {
    $(`#${id}`).addEventListener('change', () => {
      renderArchive();
      bindRecordCards();
    });
  });
  $('#recordForm').addEventListener('submit', handleSubmit);
  $('#imageFile').addEventListener('change', async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    const image = await readImage(file);
    currentImageUrl = image;
    $('#imagePreview').innerHTML = `<img src="${image}" alt="이미지 미리보기" />`;
  });
  $('#closeDialog').addEventListener('click', () => $('#detailDialog').close());
}

bindEvents();
resetForm();
renderAll();
